import time
import threading
import pyperclip
import sys
import os


timeout_seconds = 120 


clipboard_data = ""
clipboard_timestamp = 0

def countdown_display():
    while True:
        if clipboard_data:
            elapsed = int(time.time() - clipboard_timestamp)
            remaining = timeout_seconds - elapsed
            if remaining > 0:
                sys.stdout.write(f"\r⏳ Clipboard will be cleared in {remaining} seconds...")
                sys.stdout.flush()
            else:
                sys.stdout.write("\r" + " " * 50 + "\r")
        time.sleep(1)

def clipboard_watcher():
    global clipboard_data, clipboard_timestamp
    while True:
        current_data = pyperclip.paste()
        if current_data != clipboard_data:
            clipboard_data = current_data
            clipboard_timestamp = time.time()
            print(f"\n📋 Copied new content: {clipboard_data[:50]}{'...' if len(clipboard_data) > 50 else ''}")
        elif clipboard_data and (time.time() - clipboard_timestamp > timeout_seconds):
            pyperclip.copy("")
            print("\n🧹 Clipboard cleared for privacy.")
            clipboard_data = ""
            clipboard_timestamp = 0
        time.sleep(1)

if __name__ == "__main__":
    print("📌 Clipboard Auto-Cleaner is running...")
    print(f"🕒 Timeout: {timeout_seconds} seconds")
    print("-" * 40)

    threading.Thread(target=clipboard_watcher, daemon=True).start()
    threading.Thread(target=countdown_display, daemon=True).start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n❌ Exiting...")
